// COS30008, Tutorial 10, 2022

#pragma once

// enable default test
//#define TEST 0

// enable copy contructor test
//#define TEST 1

// enable assignment test
//#define TEST 2

// enable assignment operator test
//#define TEST 3

// enable move test
//#define TEST 4

// enable pointer copy test
//#define TEST 5

// enable clone test
//#define TEST 6

// enable handle test
//#define TEST 7
