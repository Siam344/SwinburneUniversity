from assignment2 import split_and_sort

nums = [5, 4, -6, -10]
result = split_and_sort(nums)
