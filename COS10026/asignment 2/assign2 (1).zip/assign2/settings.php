<?php
    $host = "feenix-mariadb.swin.edu.au";
	$user = "s103597864";
	$pwd = "MSql*Int!9";
	$sql_db = "s103597864_db";
?>