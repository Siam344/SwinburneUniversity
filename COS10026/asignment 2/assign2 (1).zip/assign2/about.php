<!DOCTYPE html>
<html lang="en">
<div class="header">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>

    
   
    <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="stylesheet/style.css">

    <?php
	    include_once "header.inc";
	?>   
                
          
      
       
</head>
 



<body>
   
    

 

    

    
<div class="about-me-nich"> <br>
    Name:  Nicholas Davenport <br>
         Student ID: s103705081 <br>
         Course:  Bachelor of Computer Science <br>
         Email:<a href="https://outlook.office365.com/mail/inbox/id/AAQkADdjNDE3NWI1LWMyNTUtNDhkOC05YTUwLWNiMzk4OTcxNTQ3MAAQACZuVZ5BWBRIrf4uOA2SvYU%3D"> s103705081@student.swin.edu.au </a> </p> 
    
In my spare time I enjoy hanging around with friends as well as things such as playing video games, going to the gym and working.
<br> For work I mostly do various trades such pool building and Alucobond cladding which Is essentially where I stick big aluminium sheets to Factory walls. <br> 
recently I have been more orientated towards deliveroo work which is basically food delivery.


</div>
<figure id="nich-border">
    <img src="stylesheet/images/photonich.jpg" alt="nich"  />   </figure>

    <figure id="Hridita-border">
        <img src="stylesheet/images/hridita.jpg" alt="Hridita"  />   </figure>

        <figure id="Siam-border">
            <img src="stylesheet/images/siamnew.jpg" alt="Siam"  />   </figure>

            <figure id="Aiden-border">
                <img src="stylesheet/images/Aiden.jpg" alt="Aiden"  />   </figure>

                <figure id="Tahseen-border">
                    <img src="stylesheet/images/Tahseen.png" alt="Tahseen"  />   </figure>
    <table id="swinburne-timetable" border="1">
        <tr> 
            <th>Time</th>
        <th>Monday</th>
        <th>Tuesday</th>
        <th>Wednesday</th>
        <th>Thursday</th>
        <th>Friday</th>
        </tr>
        <td>8:30am</td> <td div class="pink"> <b>COS10026</b>
            <br> live Online(1)
            <br> Hawthorn ONLINE
           </td>         </div>
           <td div class="purple" rowspan="4"> <b>COS10009</b>
            <br> live Online(1)
            <br> Hawthorn ONLINE </td>
        <td></td>
            <td div class="beige" rowspan="5">
        
                <b>COS10006</b>
                <br> Lab 1(14)
                <br> Hawthorn ATC329
        </div>
        
            </td>
            <td></td>
        <tr></tr>
        <td>9:30am</td>
        <td></td>
        <td></td>
        <td></td>
        <tr></tr>
        <td>10:30am</td>  <td div class="pink"> <b>COS10026</b>
            <br> Seminar 1 (3)
            <br> Hawthorn EN310 </td> </div>
           </td>
           <td></td>
           <td></td>
           <td></td>
        <tr></tr>
        <td>11:30am <br> <br> </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <tr></tr>
        <td>12:30pm </td> <td div class="beige" rowspan="2"> <b>COS10006</b>
            <br> Lecture 1(2)
            <br> Hawthorn BA403
           </td>
           <td div class="pink" rowspan="2"> <b>COS10026</b>
            <br> Workshop 1(2)
            <br> Hawthorn BA408
           </td> </div>
        <td rowspan="2"> </td>
           <td div class="purple" rowspan="2"> 
            <b>COS10009</b>
            <br> Workshop 1 (3)
            <br> Hawthorn AS404
        <td></td>
           </td>
           <tr><td>1:30pm <br> <br> </td>
            <td></td>
        
           
          <tr><td>2:30pm <br> <br> </td>
            <td div class="blue" rowspan="3"> <b>COS10004</b>
                <br> live Online(1)
                <br> Hawthorn ONLINE
               </td>
            <td div class="purple" rowspan="4">
                <b>COS10009</b>
                <br> Lab 1(18)
                <br> Hawthorn AS405
            </td>
        <td></td>
            <td div class="blue" rowspan="3">
                <b>COS10004</b>
                <br> Lab 1(23)
                <br> Hawthorn BA607
            </td>
            <td></td>
        </tr> 
        <tr>
        </tr>
        <td>3:30pm</td>
        <td></td>
        <td></td>
        <tr></tr>
        <td>4:30pm</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <tr>
        </table>

  <br>
  
  <div class="about-me-siam"> <br>
    Name:  Nur E Siam <br>
         Student ID: s103842784 <br>
         Course:  Bachelor of Computer Science <br>
         Email:<a href="103842784@student.swin.edu.au"> 103842784@student.swin.edu.au </a> </p> 
    I am Nur E Siam. First year student at Swinburne University of Technology, majoring sodtware development. I love to play FPS games and watch anime and TV series in my spare time.
   
</div>

<br>
<br>
<br>
<br>
        <table id="swinburne-timetable" border="1">
            <tr> 
                <th>Time</th>
            <th>Monday</th>
            <th>Tuesday</th>
            <th>Wednesday</th>
            <th>Thursday</th>
            <th>Friday</th>
            </tr>
            <td>8:30am</td> <td div class="pink"> <b>COS10026</b>
                <br> live Online(1)
                <br> Hawthorn ONLINE
               </td>         </div>
               <td div class="purple" rowspan="3"> <b>COS10009</b>
                <br> live Online(1)
                <br> Hawthorn ONLINE </td>
            <td div class="purple" rowspan="3"> <b>COS10009</b>
                <br> live Online(17)
                <br> Hawthorn ONLINE </td>
                <td></td>
            </div>
            
                </td>
                <td></td>
            <tr></tr>
            <td>9:30am</td>
            <td></td>
            <td></td>
            <td></td>
            <tr></tr>
            <td>10:30am</td>  <td div class="pink"> <b>COS10026</b>
                <br> Seminar 1 (3)
                <br> Hawthorn EN310 </td> </div>
               </td>
               <td></td>
               <td></td>
               <td></td>
               <td></td>
            <tr></tr>
            <td>11:30am <br> <br> </td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <tr></tr>
            <td>12:30pm </td> <td>
               </td>
               <td div class="pink" rowspan="2"> <b>COS10026</b>
                <br> Workshop 1(2)
                <br> Hawthorn BA408
               </td> </div>
            <td div class="blue" rowspan="2">
                <b>COS10004</b>
                <br> Lab 1(3)
                <br> Hawthorn EN207 </td>
               <td>
            <td></td>
               </td>
               <tr><td>1:30pm <br> <br> </td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
               
              <tr><td>2:30pm <br> <br> </td>
                <td div class="blue" rowspan="2"> <b>COS10004</b>
                    <br> live Online(1)
                    <br> Hawthorn ONLINE
                   </td>
                <td>
                </td>
            <td div class="purple" rowspan="3"> 
                <b>COS10009</b>
                <br> Workshop 1 (5)
                <br> Hawthorn AS404</td>
                <td></td>
                
                <td></td>
            </tr> 
            <tr>
            </tr>
            <td>3:30pm</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            
            </td>
            <tr></tr>
            <td>4:30pm</td>
            <td></td>
            <td></td>
            <td div class="beige" rowspan="5">
            
                <b>COS10025</b>
                <br> Workshop 1(22)
                <br> Hawthorn EN202</td>
            <td></td>
            <td></td>
            <tr>
                <tr></tr>
                <td>5:30pm</td>
                <td></td>
                <td div class="beige" rowspan="5">
            
                    <b>COS10025</b>
                    <br> Seminar 1(1)
                    <br> Hawthorn </td>
                <td></td>
                <td></td>
                
                <tr>
            </table>

            <br>

            <div class="about-me-aiden"> <br>
                Name:  Aiden Large <br>
                 Student ID: 103597864 <br>
                 Course: Bachelor of Engineering (Honours)/Bachelor of Computer ScienceCourse <br>
                     Email:<a href="103597864@student.swin.edu.au"> 103597864@student.swin.edu.au </a> </p> 
                     I have a pet ferret. In my spare time I watch Netflix.
        </div>
            
            <br>
            <br>
            <br>
            <br>
            <table id="swinburne-timetable" border="1">
                <tr> 
                    <th>Time</th>
                <th>Monday</th>
                <th>Tuesday</th>
                <th>Wednesday</th>
                <th>Thursday</th>
                <th>Friday</th>
                </tr>
                <td>8:30am</td> <td div class="beige"> <b>COS10026</b>
                    <br> live Online(1)
                    <br> Hawthorn ONLINE
                   </td>         </div>
                   <td div class="purple" rowspan="4"> <b>COS10009</b>
                    <br> live Online(1)
                    <br> Hawthorn ONLINE </td>
                <td div class="purple" rowspan="4">  <b>COS10009</b>
                    <br> Workshop(6)
                    <br> Hawthorn ONLINE</td>
                    <td></td>
                </div>
                
                    </td>
                    <td></td>
                <tr></tr>
                <td>9:30am</td>
                <td></td>
                <td></td>
                <td></td>
                <tr></tr>
                <td>10:30am</td>  <td></td> <td div class="blue" rowspan="3"> <b>COS10004</b>
                    <br> Lab 1 (4)
                    <br> Hawthorn BA603 </td>
                   <td></td>
                   <td></td>
                   <td></td>
                <tr></tr>
                <td>11:30am </td>
                <td></td>
                <td> </td>
                <td></td>
                <td></td>
                

                <tr></tr>
                <td>12:30pm </td> <td>
                   </td>
                   <td div class="beige" rowspan="2"> <b>COS10026</b>
                    <br> Workshop 1(2)
                    <br> Hawthorn BA408
                   </td>
                <td div class="pink" rowspan="2"> 
                    <b>COS10025</b>
                    <br> Workshop 1 (19)
                    <br> Hawthorn EN307 </td>
                   <td  rowspan="1"> 
                    
                </td>
                <td></td>
                   </td>
                   <tr><td>1:30pm <br> <br> </td>
                    <td div class="beige" rowspan="1"> <b>COS10026</b>
                        <br> Seminar 1(6)
                        <br> Hawthorn ATC329</td>
                <td></td>
                   <td></td>
                  <tr><td>2:30pm <br> <br> </td>
                    <td div class="blue" rowspan="1"> <b>COS10004</b>
                        <br> live Online(1)
                        <br> Hawthorn ONLINE
                       </td>
                    <td></td>
                    
                <td div class="purple" rowspan="3">
                    <b>COS10004</b>
                    <br> Lab 1(19)
                    <br> Hawthorn ATC325</td>
                    <td></td> 
                
                    <td></td>
                </tr> 
                <tr>
                </tr>
                <td>3:30pm</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <tr></tr>
                <td>4:30pm</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <tr><td>5:30pm</td>
                <td></td>
                <td div class="pink" rowspan="1"> 
                    <b>COS10025</b>
                    <br> Seminar (1)
                    <br> Hawthorn Online</td> 
                <td></td>
                <td></td>
                <td></td>
                <tr><td>6:30pm </td>
                    <td></td>
                    <td></td> 
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
        </tr>

                </table>

                <br>



                <div class="about-me-tahseen"> <br>
                    Name:  Tahseen Zubaerr <br>
                      Student ID : 103850541 <br>
                         Course:  Bachelor of Computer Science <br>
                         Email:<a href="tahseenzubaerr56@gmail.com"> S103850541@student.swin.edu.au </a> </p> 
                         i am a student of Swinburne university ,majoring in software development .

                         i am from Dhaka , Bangladesh . its a beautiful country with a lot of people, food and culture.
                         
                         my favourite tv shows are - fleebag , breaking bad , better call saul, bojack horseman (good stuff)
            </div>
                
                <br>
                <br>
                <br>
                <br>


                <table id="swinburne-timetable" border="1">
                    <tr> 
                        <th>Time</th>
                    <th>Monday</th>
                    <th>Tuesday</th>
                    <th>Wednesday</th>
                    <th>Thursday</th>
                    <th>Friday</th>
                    </tr>
                    <td>8:30am</td> <td div class="pink"> <b>COS10026</b>
                        <br> live Online(1)
                        <br> Hawthorn ONLINE
                       </td>         </div>
                       <td div class="purple" rowspan="4"> <b>COS10009</b>
                        <br> live Online(1)
                        <br> Hawthorn ONLINE </td>
                    <td> <td div class="purple" rowspan="3"> 
                        <b>COS10009</b>
                        <br> Workshop 1 (7)
                        <br> Hawthorn AS404</td>
                        <td></td>
                    </div>
                    
                        </td>
                        
                    <tr></tr>
                    <td>9:30am</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    
                    <tr></tr>
                    <td>10:30am</td>  <td> </td> </div>
                       </td>
                       <td></td>
                       <td></td>
                       <td></td>
                       <td></td>
                    <tr></tr>
                    <td>11:30am <br> <br> </td>
                    <td div class="pink"> <b>COS10026</b>
                        <br> Seminar 1 (4)
                        <br> Hawthorn ATC309 </td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <tr></tr>
                    <td>12:30pm </td> <td div class="beige" rowspan="2"> <b>COS10006</b>
                        <br> Lecture 1(2)
                        <br> Hawthorn BA403
                       </td>
                       <td div class="pink" rowspan="2"> <b>COS10026</b>
                        <br> Workshop 1(2)
                        <br> Hawthorn BA408
                       </td> 
                       <td></td>
                       <td></td>
                    </div>
                       
                    <td> </td>
                       
                    
                       </td>
                       <tr><td>1:30pm <br> <br> </td>
                        <td></td>
                    <td></td>
                    <td></td>
                       
                      <tr><td>2:30pm <br> <br> </td>
                        <td div class="blue" rowspan="3"> <b>COS10004</b>
                            <br> live Online(1)
                            <br> Hawthorn ONLINE
                           </td>
                        <td div class="purple" rowspan="4">
                            <b>COS10009</b>
                            <br> Lab 1(18)
                            <br> Hawthorn AS405
                        </td>
                    <td></td>
                        <td div class="blue" rowspan="3">
                            <b>COS10004</b>
                            <br> Lab 1(23)
                            <br> Hawthorn BA607
                        </td>
                        <td></td>
                        
                    </tr> 
                    <tr>
                    </tr>
                    <td>3:30pm</td>
                    <td></td>
                    <td></td>
                    <tr></tr>
                    <td>4:30pm</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <tr>
                        <td>5:30pm</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td div class="beige" rowspan="5">
                    
                        <b>COS10006</b>
                        <br> Lab 1(14)
                        <br> Hawthorn ATC329</td>
                    <td></td>
                    <tr></tr>
                    <td>6:30pm</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    
                    <tr>
                        <td>7:30pm</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    
                    <tr></tr>
                   
                    </table>

                    <br>


                    <div class="about-me-hridita"> <br>
                        Name:  Hridita Dewan <br>
                          Student ID: 103804179 <br>
                             Course:  Bachelor of Computer Science <br>
                             Email:<a href="Email: 103804179@student.swin.edu.au"> S103804179@student.swin.edu.au </a> </p> 
                             My name is Hridita Dewan, and I am from Chittagong, Bangladesh. I am a first-year international student majoring in Software Development at Swinburne University of Technology.
                              I spend my time learning about programming and passionate in gaining more insight about the different areas of the technology world including data analysis,
                               web development etc and its uses in daily life. I love to share what I learn but also learn from my peers. I come from a small indigenous community known as “Chakma”.
                                We reside in Rangamati of Chittagong Hill Tracts, and we practice our own faith, language, tradition, and culture. However, I grew up in Chittagong and was privileged to study in one of the prestigious schools of Chittagong.
                                 I love dogs, trying out new food from different cultures. My favourite foods are ramen and boba. I am always down to go out to have a good time. In terms of music, I typically listen to a wide variety - everything from EDM to pop to indie to lofi and definitely Bollywood music.
                                  I have watched a range of series during my leisure starting from The Big Bang Theory to Bridgerton to 13 Reasons Why. All in all, F.R.I.E.N.D.S has to be my top pick which I am a huge fanatic of!
                    </div>
                    
                    <br>
                    <br>
                    <br>
                    <br>


                    <table id="swinburne-timetable" border="1">
                        <tr> 
                            <th>Time</th>
                        <th>Monday</th>
                        <th>Tuesday</th>
                        <th>Wednesday</th>
                        <th>Thursday</th>
                        <th>Friday</th>
                        </tr>
                        <td>8:30am</td> <td div class="pink"> <b>COS10026</b>
                            <br> live Online(1)
                            <br> Hawthorn ONLINE
                           </td>         </div>
                           <td div class="blue" rowspan="4"> <b>COS10009</b>
                            <br> live Online(1)
                            <br> Hawthorn ONLINE </td>
                        <td></td>
                            <td> 
                        
                            </td>
                            <td></td>
                        <tr></tr>
                        <td>9:30am</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <tr></tr>
                        <td>10:30am</td>  
                           </td>
                           <td></td>
                           <td></td>
                           <td div class="blue"> <b>COS10009</b>
                            <br> Lab 1 (6)
                            <br> Hawthorn ATC 625</td>
                           <td></td>
                           <td></td>
                        <tr></tr>
                        <td>11:30am <br> <br> </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <tr></tr>
                        <td>12:30pm </td> <td div class="beige" rowspan="2"> <b>COS10006</b>
                            <br> Lecture 1(2)
                            <br> Hawthorn BA201
                           </td>
                           <td div class="pink" rowspan="2"> <b>COS10026</b>
                            <br> Workshop 1(2)
                            <br> Hawthorn BA408
                           </td> </div>
                        <td rowspan="1"> </td>
                        <td></td>
                           <td> 
                        </td>
                           </td>
                           <tr><td>1:30pm <br> <br> </td>
                            <td></td>
                        <td></td>
                           <td></td>
                          <tr><td>2:30pm <br> <br> </td>
                            <td></td> 
                               
                            <td div class="beige" rowspan="6">
                                <b>COS10006</b>
                                <br> Lab 1(2)
                                <br> Hawthorn ATC329
                            </td>
                        <td div class="blue" rowspan="3">
                            <b>COS10009</b>
                            <br> Lab 1(5)
                            <br> Hawthorn AS404</td>
                            <td> 
                            </td>
                            <td div class="purple" rowspan="2"> 
                                <b>COS10025</b>
                                <br> Workshop 1 (12)
                                <br> Hawthorn EN405</td>
                        </tr> 
                        <tr>
                        </tr>
                        <td>3:30pm</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <tr></tr>
                        <td>4:30pm</td>
                        <td div class="pink" rowspan="2"> <b>COS10026</b>
                            <br> Seminar 1(1)
                            <br> Hawthorn ATC607</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        
                        <tr>
                            <tr>
                                <td>5:30pm</td>
                                <td></td>
                                <td div class="purple" rowspan="1"> 
                                    <b>COS10025</b>
                                    <br> Seminar (1)
                                    <br> Hawthorn Online</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr><td>6:30pm</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </table>
        </body>
<br>
<br>
<!-- Footer -->
    <?php
	    include_once "footer.inc";
	?>


</body>
</html>