from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models import User, Product, Order, Delivery, SalesReport, ShoppingCart
from werkzeug.security import generate_password_hash, check_password_hash

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']
        hashed_pw = generate_password_hash(password, method='sha256')
        new_user = User(name=name, email=email, password=hashed_pw, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Account created!', 'success')
        return redirect(url_for('main.login'))
    return render_template('register.html')

@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('main.dashboard'))
        else:
            flash('Login Failed. Check your credentials', 'danger')
    return render_template('login.html')

@main.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('main.index'))

@main.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', name=current_user.name, role=current_user.role)

@main.route('/products')
def product_list():
    products = Product.query.all()
    return render_template('product_list.html', products=products)

@main.route('/add_product', methods=['GET', 'POST'])
@login_required
def add_product():
    if current_user.role != 'owner':
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        description = request.form['description']
        product = Product(name=name, price=price, description=description)
        db.session.add(product)
        db.session.commit()
        flash('Product added!')
        return redirect(url_for('main.product_list'))
    return render_template('product_form.html')

@main.route('/add_to_cart/<int:product_id>')
@login_required
def add_to_cart(product_id):
    cart_item = ShoppingCart.query.filter_by(user_id=current_user.id, product_id=product_id).first()
    if cart_item:
        cart_item.quantity += 1
    else:
        cart_item = ShoppingCart(user_id=current_user.id, product_id=product_id, quantity=1)
        db.session.add(cart_item)
    db.session.commit()
    return redirect(url_for('main.view_cart'))

@main.route('/cart')
@login_required
def view_cart():
    cart_items = ShoppingCart.query.filter_by(user_id=current_user.id).all()
    total = sum(item.product.price * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)

@main.route('/checkout')
@login_required
def checkout():
    cart_items = ShoppingCart.query.filter_by(user_id=current_user.id).all()
    if not cart_items:
        return redirect(url_for('main.view_cart'))
    total = sum(item.product.price * item.quantity for item in cart_items)
    new_order = Order(user_id=current_user.id, total=total)
    db.session.add(new_order)
    db.session.commit()
    for item in cart_items:
        report = SalesReport.query.filter_by(product_id=item.product_id).first()
        if report:
            report.quantity_sold += item.quantity
            report.total_sales += item.product.price * item.quantity
        else:
            report = SalesReport(product_id=item.product_id, quantity_sold=item.quantity,
                                 total_sales=item.product.price * item.quantity)
            db.session.add(report)
        db.session.delete(item)
    db.session.commit()
    flash('Order placed successfully!')
    return redirect(url_for('main.dashboard'))

@main.route('/sales-report')
@login_required
def sales_report():
    if current_user.role != 'owner':
        return redirect(url_for('main.dashboard'))
    reports = SalesReport.query.all()
    return render_template('sales_report.html', reports=reports)
