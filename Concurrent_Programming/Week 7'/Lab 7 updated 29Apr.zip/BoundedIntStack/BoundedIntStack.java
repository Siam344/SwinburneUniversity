public class BoundedIntStack {

	private int MAXSIZE = 2;
	private ArrayList<Integer> list = new ArrayList(Integer)();
	
	public Object pop() {
		if (list.size() == 0) return null;
		Object result = list.remove(0);
		return result;
	}

	public bool push(int number) {
		if (list.size() == MAXSIZE) return false;
		
		list.add(0, number);
		return true;
	}

	public int getSize(){
		return list.size();
	}

}
