import java.util.Random;

public class Main extends Thread
{
  static BoundedIntStack stack =new BoundedIntStack();
  boolean popInstead;
  int threadID;
  Random theRandom = new Random();


  public Main(boolean popInstead, int id)
  {
    this.popInstead = popInstead;
    this.threadID = id;
  }

  public void run()
  {
    if(popInstead)
      popper();
    else
      pusher();
  }

  void pusher()
  {
    for(int i=0; i<4; i++)
    {
      int number = theRandom.nextInt();

      stack.push(number);
      //System.out.println("Pusher Thread " + threadID + " pushed " + number + ";");

    }
  }

  void popper()
  {
	for(int i=0; i<4; i++)
    {

        Object result = stack.pop();
        //System.out.println("Popper Thread " + threadID + " popped " + result + ";");

    }
  }



  public static void main(String[] args)
  {

      int numPushers = 2;
      int numPoppers = 2;

      Main[] pushers = new Main[numPushers];
      Main[] poppers = new Main[numPoppers];

      for(int i = 0; i < numPushers; i++)
      {
        pushers[i] = new Main(false, i);
        pushers[i].start();
      }

      for(int i = 0; i < numPoppers; i++)
      {
        poppers[i] = new Main(true, i);
        poppers[i].start();
      }
  }
}
