import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
import java.util.ArrayList;

public class BoundedIntStack {

	final Lock lock = new ReentrantLock();
	final Condition notFull = lock.newCondition();
	final Condition notEmpty = lock.newCondition();

	private int MAXSIZE = 2;
	private ArrayList<Integer> list = new ArrayList<Integer>();

	public Object pop() {

		Object result = null;
		
		lock.lock();
		try{
			while(list.size() == 0) { 
				System.out.println("Stack is empty, waiting for pushing;");
				notEmpty.await();
			}
			result = list.remove(0);
			System.out.println(result + " popped");
			notFull.signal();

		}catch(InterruptedException e){}
		finally {
			lock.unlock();
		}

		return result;
	}

	public boolean push(int number) {
		
		lock.lock();
		try{
			while(list.size() == MAXSIZE) {
				System.out.println("Stack is full, waiting for popping;");
				notFull.await();
			} 
				
			list.add(0, number);
			System.out.println(number + " pushed");
			notEmpty.signal();
		}catch(InterruptedException e){}
		finally {
			lock.unlock();
		}

        return true;
	}

	public int getSize(){
		int size = -1;
		lock.lock(); //start of crticial section
		try{
			size = list.size();	
		}catch(Exception e){}
		finally {
			lock.unlock();
		} //end of critical section

		return size;
	}

}